Azure Pipelines Scripts
=======================

This directory contains scripts used for [testing YCM on Azure
Pipelines](https://dev.azure.com/YouCompleteMe/YCM/_build?definitionId=1). They
should not normally be run by users.
